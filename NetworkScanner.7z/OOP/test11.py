class S:
    nInstances=0

    def __init__(self):
        S.nInstances=S.nInstances+1
    def test(self):
        pass
    @staticmethod
    def howMany():
        pass
        #print("Nb of instances ",S.nInstances)

a=S()
b=S()
c=S()

print(S.howMany())
print(a.howMany())
#print(a.test())