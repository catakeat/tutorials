class Celsius:
    def __init__(self, temperature = 0):
        self.temperature = temperature


    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32

    def get_temperature(self):
        print("Getting value")

        return self._temperature

    def set_temperature(self, value):
        #print(self.temperature)
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        print("Setting value")
        self._temperature = value
        print(self.temperature, self._temperature)

    def display(self):
        print("self.temperature este %r iar self._temperature este %r ", (self.temperature, self._temperature))

    temperature = property(get_temperature,set_temperature)

#Celsius.display()

c=Celsius()
c.temperature=37
c.display()
'''
c.display()
print(Celsius.__dict__);
print(c.__dict__)
print(Celsius.get_temperature)

print(c.__dict__)
print(c.get_temperature())

print(c.temperature)
'''