class Celsius:
    def __init__(self,temperature=0):
        self.set_temperature(temperature)

    def to_fahrenheit(self):
        return (self.get_temperature()*1.8)+32

    def get_temperature(self):
        return self.__temperature
    def set_temperature(self,temperature):
        if temperature<-273:
            raise ValueError("Prea mica temp")
        else:
            self.__temperature=temperature

#c=Celsius(-278)
c=Celsius(37)
print(c.get_temperature())

c.set_temperature(10)
print(c.get_temperature())

#print(c.__temperature)
print(Celsius.__dict__)
print(c.__dict__)
print("Memnbru privat ",c._Celsius__temperature)