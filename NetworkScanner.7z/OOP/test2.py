class Student():
    '''Acesta este un etst'''
    def __init__(self,name,id=2001):
        self.name=name
        self.id=id

st=Student()
