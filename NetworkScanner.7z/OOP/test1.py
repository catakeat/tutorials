class Student:
    pass

Student.name="Jack"
Student.id=20001

student=Student()
print(student.name)
print(student.__dict__)
print("Atribut de clasa",Student.__dict__)
#print(student.__dict__['__dict__'])

class Elev:
    nume="Cata"
    def __init__(self):
        self.virsta=23

elev=Elev()
print(elev.__dict__)