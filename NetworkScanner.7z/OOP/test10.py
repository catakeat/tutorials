class Callback:
    def __init__(self,color):
        self.color=color
    def chColor(self):
        print(self.color)

obj=Callback("red")
cb=obj.chColor
cb()
t=Callback.chColor
t(obj)
