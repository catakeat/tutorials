while True:
    try:
      age=int(input("O virsata"))
      print(age)
      break
    except  ValueError:
      #print("un intreg")
      #break
       continue
    finally:
      print("In finally")