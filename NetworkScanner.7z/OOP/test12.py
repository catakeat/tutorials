class Methods:

    def i_method(self,x):
        print(self,x)

    def s_method(x):
         print(x)

    def c_method(cls,x):
        print(cls,x)

    s_method=staticmethod(s_method)
    c_method=classmethod(c_method)


obj = Methods()

obj.i_method(1)
Methods.i_method(obj, 2)

obj.s_method(3)
Methods.s_method(4)

obj.c_method(5)
Methods.c_method(6)