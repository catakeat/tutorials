class Student:
    def __init__(self,id):
        self.id=id
    def setData(self,value):
        self.value=value
    def display(self):
        print(self.data)


s1=Student()
s2=Student()

s1.setData("jake")
s2.setData(21212)