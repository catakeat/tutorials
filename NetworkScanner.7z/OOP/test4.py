class Rectangle:

    def __init__(self,w,h):
        self.width=w
        self.height=h
    def area(self):
        return self.width*self.height

    def  getWidth(self):
        return self.width
    def setWidth(self,width):
        self.width=width
    def getHeight(self):
        return self.height
    test=property(area)

rect=Rectangle(100,20)
print(rect.area())
rect.height=30
print(rect.area())