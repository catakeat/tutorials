class Negative(Exception):
    pass

def oops():
    raise Negative()

try:
   age=int(input("age of Universe"))
   print(age)
   if age<0:
       print("Negative")
       oops()
except ValueError:
    print("un intreg")

except Negative:
     print("Valoare pozitiva")
except:
     print("Somethibng....")
finally:
    print("In finally")