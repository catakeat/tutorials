s="picasso"
s[0]='X'

print(s)