import sys
import math

print(sys.platform)
print(math.sqrt(1001))
x="blah"
print (x*3)
