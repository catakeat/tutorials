D1={}
D1['a']=1
D1['b']=2
D1['c']=3

print(D1)