x=1
y=eval('x+1')
print(y)