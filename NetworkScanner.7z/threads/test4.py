import threading
import time
import logging

logging.basicConfig(level=logging.DEBUG,format='[%(levelname)s] (%(threadName)-9s) %(message)s',)

def f1():
    logging.debug("start")
    time.sleep(1)
    logging.debug("exit")
