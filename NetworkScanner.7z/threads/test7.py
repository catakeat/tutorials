def raising_python_exception(x,y):
    try:
        z=x/y
    except ZeroDivisionError as e:
        err=e
        print("Eroarea este {} : {} {}",err)


raising_python_exception(1,0)