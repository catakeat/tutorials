import threading

def f():
    print("apel din f")
    return
def g(id):
    print("parametru din fc Thread()",id)
if __name__=='__main__':
    for i in range(3):
        t=threading.Thread(target=f)
        t.start()

    for j in range(5):
        t=threading.Thread(target=g,args=(j,)).start()