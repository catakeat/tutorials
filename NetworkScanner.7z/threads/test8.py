import threading

def  f(id,j,k):
    print(" {} , {} , {} ".format(id, j, k))

for i in range(3):
    j=1
    k=2
    t=threading.Thread(target=f,args=(i, j, k,))
    t.start()