import threading
import time
import logging
import random

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-9s) %(message)s',)
def f ():
    t=threading.currentThread()
    r=random.randint(1,10)
    logging.debug("sleeping %s",r)
    time.sleep(r)
    logging.debug("end")
    return

for i in range(3):
    t=threading.Thread(target=f)
    t.setDaemon(True)
    t.start()

main_thread=threading.currentThread()
for t in threading.enumerate():
    if t is main_thread:
        continue
        logging.debug('joinning %s',t.getName())
        t.join()