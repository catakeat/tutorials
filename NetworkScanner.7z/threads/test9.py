import threading

def f1():
    print(threading.currentThread(),threading.current_thread())

for i in range(3):
    if i==0:
        threading.Thread(target=f1).start()
    if i==1:
        threading.Thread(name='ceva',target=f1).start()