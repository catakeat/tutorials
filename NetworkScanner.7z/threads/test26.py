import threading
import time
import logging

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-9s) %(message)s',)


class ThreadPool():

    def __init__(self):
        super().__init__()
        self.active=[]
        self.lock=threading.Lock()

    def makeActive(self,name):
        with self.lock:
            self.active.append(name)
            logging.debug("running %r",self.active)

    def makeInactive(self,name):
        with self.lock:
            self.active.remove(name)
            logging.debug("Running %r",self.active)


def f(s,pool1):
    logging.debug("Wait to join ")
    with s:
        name=threading.currentThread().getName()
        print(name)
        pool1.makeActive(name)
        time.sleep(0.5)
        pool1.makeInactive(name)

pool = ThreadPool()
s = threading.Semaphore(3)
for i in range(1,10):
    nm = 'thread' + str(i)
    t = threading.Thread(target=f,name=nm,args=(s, pool,))
    t.start()







