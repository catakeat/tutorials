import logging
logging.basicConfig(filename='test.log',
                    level=logging.DEBUG,
                    format="%(asctime)s:%(levelname)s:%(message)s"
                    )

class Pizza():

    def __init__(self,name,price):
        self.name=name
        self.price=price
        logging.debug("Pizza created {} (${})".format(self.name,self.price))

    def make(self,quantity=1):
        logging.debug("Made {} {} pizza(s)".format(quantity,self.name))

    def eat(self,quantity=1):
        logging.debug("Ate {} pizza(s)".format(quantity,self.name))

pizza_001=Pizza("artichoke",15)
pizza_001.make()
pizza_001.eat()