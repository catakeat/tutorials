import threading
import time
import numpy

event=threading.Event()

def flag():
    time.sleep(3)
    event.set()
    print("starting countdown")

    for tst in range(10):
        print("In for ",tst)
        time.sleep(0.5)

    time.sleep(7)
    print("event is cleared")
    event.clear()

def start_operations():
    event.wait()
    while event.is_set():
        print("stariung random integer task")
        x=numpy.random.randint(1,30)
        print("In poerations {}".format(x))

        time.sleep(.5)
        if x==29:
            print("True")
    print("event is cleared")

t1=threading.Thread(target=flag)
t2=threading.Thread(target=start_operations)

t1.start()
t2.start()
