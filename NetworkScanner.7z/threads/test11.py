import threading
import time
import logging

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-9s) %(message)s')


def n():
    logging.debug("start")
    logging.debug("exit")

def d():
    logging.debug("start")
    time.sleep(5)
    logging.debug("Exit")

t=threading.Thread(name='non-daemon',target=n)
d=threading.Thread(name='daemon',target=d)
d.setDaemon(True)

d.start()
t.start()
