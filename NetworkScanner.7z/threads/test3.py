import threading
import time

def f1():
    print( threading.currentThread().getName())
    time.sleep(1)
    print(threading.currentThread().getName())
def f2():
    print(threading.currentThread().getName())
    time.sleep(2)
    print(threading.currentThread)

t1 = threading.Thread(target=f1).start() # use default name
t2 = threading.Thread(name='f2', target=f2).start()