import threading
import time
import logging
import random
import queue


logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-9s) %(message)s',)
BUF_SIZE=10
q=queue.Queue(BUF_SIZE)

class Producer(threading.Thread):
    def __init__(self,selfgroup=None,target=None,name=None,args=(),kwargs=None,verbose=None):
        #threading.Thread.__init__()
        super().__init__()
        self.target=target
        self.name=name

    def run(self):
        while True:
            if not q.full():
                item=random.randint(1,10)
                q.put(item)
                logging.debug('Putting'+str(item)+':'+str(q._qsize())+'items in queue')
                time.sleep(random.random())

class Consumer(threading.Thread):
    def __init__(self,group=None,target=None,name=None,args=(),kwargs=None,verbose=None):
        super().__init__()
        self.target=target
        self.name=name
    def run(self):
        while True:
            if not q.empty():
                item=q.get()
                logging.debug('getting '+str(item)+":"+str(q._qsize())+'items in queue')
                time.sleep(random.random())


p=Producer(name='prod')
c=Consumer(name='cons')

p.start()
time.sleep(2)
c.start()
time.sleep(2)


