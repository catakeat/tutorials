import threading
import time

evt=threading.Event()
i=0
def f1():
    global i
    print("In f1")
    evt.set()
    for i in range(12):
        time.sleep(0.4)
        if i==10:
         print("trimit i {}".format(i))
         evt.clear()
         evt.wait()
        else :
         print(" thread 1 , i este {}".format(i))



def f2():
   global i
   print("in f2")
   while evt.is_set():
     print("in thread 2  {}".format(i))
     time.sleep(0.4)
     if i ==10:
      #evt.clear()
      print("am primit un {} ".format(i))
      print("intru la somn")
      time.sleep(5)
      print("m-am trezit")
      evt.set()
      #evt.set()
     #else:
      #   evt.set()
       #  print(" thread 2 , i este  {} ".format(i))
        # evt.clear()
         #evt.wait()

t1=threading.Thread(name='t1',target=f1)
t1.start()
t2=threading.Thread(name='t2',target=f2)
t2.start()


for a in range(12):
    print(a)