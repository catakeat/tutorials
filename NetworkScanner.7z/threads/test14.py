import threading
import time

class MyThread(threading.Thread):
    def run(self):
        time.sleep(5)
for i in range(3):
    t=MyThread()
    t.start()
    print("t is alive ",t.isAlive)
    t.join()
    print("t is alive ", t.isAlive)
