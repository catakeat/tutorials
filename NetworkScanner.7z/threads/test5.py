import threading
import time

def n():
    print("Enter")
    print("Exit")

def d():
    print("Enter")
    time.sleep(5)
    print("Exit")

if __name__=='__main__':
    t1=threading.Thread(name="non-daemon",target=n)
    t2=threading.Thread(name="daemon",target=d)

    t2.setDaemon(True)

    t2.start()
    t1.start()

    t2.join()
    t1.join()


