import threading
import time
import logging

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-9s) %(message)s',)

def n():
    logging.debug('non daemon Starting')
    logging.debug('non daeomon Exiting')

def d():
    logging.debug('daemon Starting')
    time.sleep(5)
    logging.debug('daemon Exiting')


t = threading.Thread(name='non-daemon', target=n)
d = threading.Thread(name='daemon', target=d)

#d.setDaemon(True)
d.start()
d.join(2)
if d.isAlive:
    t.start()
else:
    print("d is alive ", d.isAlive())


