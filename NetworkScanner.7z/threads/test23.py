import threading
import logging


def worker_with(lock):
    with lock:
        print("Lock acquired via with")


def worker_not_with(lock):
    lock.acquire()

    try:
        print("Lock acquired directly")
    finally:
        lock.release()

lock=threading.Lock()
w=threading.Thread(target=worker_with,args=(lock,))
nw=threading.Thread(target=worker_not_with,args=(lock,))

w.start()
nw.start()

