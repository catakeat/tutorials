import threading
import time
import logging

logging.basicConfig(level=logging.DEBUG,
                    format='(%(threadName)-9s) %(message)s', )


def locker(lock):
    logging.debug('Starting')
    while True:
        lock.acquire(0)
        try:
            logging.debug("Trying to lock")
            time.sleep(1.0)
        finally:
            logging.debug("Not locking")
            lock.release()

lock=threading.Lock()
lock.acquire()
t=threading.Thread(target=locker,args=(lock,))
t.setDaemon(True)
t.start()
