my_nums=[x*x for x in [1,2,3,4,5]]

print( my_nums)