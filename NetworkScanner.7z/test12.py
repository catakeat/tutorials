D={}

D['composer']='Beethoven'
D['Period']='Classic'
D['Symphony']=9

print("Dictionarul este ",D)

D1={'Composer':{'first':'Johannes','last':'brahms'},
    'Period':'Romantic',
    'Piece':['Piano Concerto No. 1', 'Piano Concerto No. 2',
		    'Symphony No. 1', 'Symphony No. 2',
		    'Violin Concerto in D Major',
		    'Hungarian Dances']
    }
print("Dictionar1",D1)