from test12 import D1

print(D1)

listof_keys=D1.keys()
print("lista of keys ",listof_keys,type(listof_keys))
print(list(listof_keys))