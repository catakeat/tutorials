for x in open("main.py"):
    print(x)