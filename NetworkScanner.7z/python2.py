lista=[1,2,3,4]
print(set(lista))
#empty set
empty_set=set([])
empty_set.add(5)
empty_set.add(6)
empty_set.add(7)
empty_set.add(8)
print(empty_set)
empty_set.update(9,20)