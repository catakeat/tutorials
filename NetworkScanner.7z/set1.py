s=([1,2,3,])
print(s)

set=set(["I", "was", "a", "child", "and", "she", "was", "a", "child"])
print(set)

s2={1,2.0,"three",(4,5)}
print(s2)
