string_data="123"
new_int=int(string_data)

print(new_int)
print(float(new_int))
print(complex(new_int))
print(repr(string_data))
print(eval(string_data))

#frozenset
letters=('a','b','c','d','e')
print(frozenset(letters))
#or
my_raw_string="Good morning !"
print(set(my_raw_string))
p=set("Python tutorial")

#does not work
p[0]=12
print(p[0])



