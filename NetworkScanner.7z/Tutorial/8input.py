number=input("Enterv a number")
#but this is a atring  so let's convert it
print(type(number))
converted=int(number)

print(type(converted))
