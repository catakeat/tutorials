#print(value1, ..., sep=' ', end='\n', file=sys.stdout, flush=False)
print(1,2,3,34 ,sep='^',end='&')

"""
Sometimes we would like to format our output to make it look better. This can be done by using the str.format() method. 
"""
x=12;y=15
print("\nThe value of x is {} and the valueof y is {} ".format(x,y))
print("Today my favorites cars are {0} and  {1}".format("Mercedes","Toyota"))
print("Yesterday my favorites cars were {1} and {0}".format("Mercedes","Toyota"))

print(" {name} and age={age}".format(name='I am Jon Snow',age='30'))

x2=1111.2345567778
print("x is %3.2f" % x2)