from math import *
import sys

#we imported everything from that module
print("The value of pi is", pi)

"""
Python looks at several places. 
Interpreter first looks for a built-in module then (if not found) into a list of directories defined in sys.path. The search is in this order.

    The current directory.
    PYTHONPATH (an environment variable with a list of directory).
    The installation-dependent default directory.

"""



print(sys.path)