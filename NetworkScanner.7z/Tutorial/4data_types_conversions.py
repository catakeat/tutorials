"""
We can convert between different data types by using different type conversion
functions like int(), float(), str() etc.
"""
x=10.6
print("x type is ",type(x))
x1=int(x)
print(x1);print("x1 type is ",type(x1))

x2=str(x)
print(x2);print("x2 type is ",type(x2))

#list to set
mylist=['1','2','3','4','5']
print("mylist  type is ",type(mylist))
myset=set(mylist)
print(myset)
print("myset type is ",type(myset))

#list tu tuple
mytuple=tuple(mylist)
print(mytuple)
print("mytuple type is ",type(mytuple))

#if we waant a conversion to a dictionary each elements must be a pair
list1=[["elem1","val1"],["elem2","val2"],["elem3","val3"]]
mydict=dict(list1)
print(mydict)
print("mydict type is ",type(mydict))

#some more  : the len function works for these all types