a=10#assign a value of 10 for a

#see the if else indentation and block

if(a==10):
    print("a is 10")
    print("Yes indeed a is 10")
else:
    print("a is not 10")
    print("indeed a is not 10")

#Blocks of text

new_block="This is a \
a large block of text \
spreading on multiple lines"

print(new_block)

text_block="""This is my 
nice and well formated 
text block :)
"""

print(text_block)

# as simple varible
simple_variable="mytext"# the same as 'mytext' , simple quoted
print("mytext is",simple_variable)
#the last character could be accesed ; is is zero index vs 1 index in R
print("last character ",simple_variable[len(simple_variable)-1])


#many statement on a single line
b=1;c=2;d=3
print("a,b,c are :", a, b, c)# the correct space between a b c

#multiple assignment
t=f=g=25
print(" t and f and g", t, f, g)
#we can change this type
t=f=g="I ama string now"
print("g=t=f ",t)

# the id function.It point in the same memory location
print(" id(t),id(f),id(g)",id(t),id(f),id(g))
t=11
#now t point to a differnt memory location ;
#THIS IS KNOWN AS A IMMUTABLE OBJECT
print(" id(t),id(f),id(g)",id(t),id(f),id(g))

#docstrings :it is the string occuring as the first line in a function or python class;
#you get it only using triple quotas not the ussual '#'
def myfunction():
    """this is a docstring ; it appeasrs as the first line in triple quotes"""
    return
#docstring is accesible as
print(myfunction.__doc__)
