a=2 # global

print(" a adress , id(a)  {} ,{}".format(id(a),id(2)))

b=3
print("b adresss , id(b)  {} {}".format(id(b),id(3)))

def f_local():
    print("Calling f_local")
    a=10
f_local()
print(a)

#global keyword
def f_global():
    global a
    a=10

f_global()
print("I just modified a ",format(a))

#nonlocal keyword

def onefunction():
    wow="Wow"


    def otherfunction():
        wow="wow-wow"

    otherfunction()
    print("wow is {}".format(wow))

    def other_otherfunction():
        nonlocal wow
        wow="I just changed this"
    other_otherfunction()
    print("wow is :{}".format(wow))


onefunction()# wow is unchanged since