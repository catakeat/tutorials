'''
There are three distinct numeric types: integers, floating point numbers, and complex numbers.
In addition, Booleans are a subtype of integers. Integers have unlimited precision.
 Floating point numbers are usually implemented using double in C;
 information about the precision and internal representation of floating point numbers for
 the machine on which your program is running is available in sys.float_info.
 Complex numbers have a real and imaginary part, which are each a floating point number.
  To extract these parts from a complex number z, use z.real and z.imag.
  (The standard library includes additional numeric types, fractions
  that hold rationals, and decimal that hold floating-point numbers with user-definable precision.)
'''
"""Python data types are :
numbers
,string
,list
,dictionary"""

myint=10;print("myint type is ",type(myint))
myfloat=10.1234567890;print("myflot type is ",type(myfloat))

print("yint ",myint)
print("myfloat ",myfloat)


z = complex(3, -3)
print(z);print("z type is ",type(z))

z = complex(1)
print(z)

z = complex()
print(z)

z = complex('5-7j')
print(z)

#strings

string="Hello Python!"
print("string type is ",type(string))
print(string[0])
print(string[2:])
print(string[2:3])
print(string*3)
print(string+"Abracadabra !")

#escapes newlines
e_str="This is \n a nice python \n program"
print(e_str)
#escape special characters
e_str1="This is a\' nice string "
print(e_str1)


#lists
list=['test',1.234,34.5,"other things"]
print(" list type is ",type(list))
print(list)
print(list[0])
print(list[2:])
print(list[1:3])
print(list*3)

list1=["my alter ego",1.0]
print(list+list1)

#tuples ; brackets are used () unlike []  for list
#tuples cannot be updated ; read-only data

tuple=('abdce',323,1234.4567,"Other things here")
smalltuple=("I am a small tuple",1234)

print(tuple)
print("mytuple type is ",type(tuple))
print(tuple[0])
print(tuple[1:3])
print(tuple[2:])
print(smalltuple+tuple)
print(tuple*2)

#we try to update a tuple and we get an error
#tuple[3]="Test this"
#print(tuple[3])


"""
Dictionaries are enclosed by curly braces ({ })
 and values can be assigned and accessed using 
 square braces ([]).
 They key value type , structures.
"""

my_dict={}
my_dict['elem1']="This is element one"
my_dict['elem2']="This is element2"
my_dict['elem3']="This is element 3"

print("type of my_dict is ",type(my_dict))
print(my_dict)
print(my_dict['elem1'])
print(my_dict.keys())
print(my_dict.values())

#None is a scpecial type.It is a null value; is not false;not empty string
#None==None but different of anything else


























