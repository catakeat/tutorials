class Person:

    def __init__(self,name):
        self.name=name

    #the property will have method name
    @property
    def age(self):

        return self.__age

    @age.setter#the same name here
    def age(self,age):
        self.__age=age


pers = Person("Oliver Bran")
pers.age="never dying boy"
print(pers.age)

class Car:
    def __init__(self,carmaker):
        self.carmaker=carmaker


    def year(self):
        return self.__year

    def set_year(self,year):
        self.__year=year

    year = property(year, set_year)

car=Car("Toyota")
car.year=1980
print(car.year)

del car.year
print(car.year)
#property function signature
#property(fget=None, fset=None, fdel=None, doc=None)