"""
+,-.*/,%
//-truncation
"""

x = 10
y = 4

print('x + y =',x+y)
print('x - y =',x-y)
print('x * y =',x*y)
print('x / y =',x/y)
print('x ** y =',x**y)

t=10//3
print(t)
print(10.0//3)

x=10;y=2
#x raised to the power of 2
print(x**y)

#comparison
x1 = 10
y1 = 12
print('x1!= y1 is',x1!=y1)
print('x1 >= y1 is',x1>=y1)
print('x1 <= y1 is',x1<=y1)
print('x1 > y1  is',x1>y1)
print('x1 < y1  is',x1<y1)
print('x1 == y1 is',x1==y1)

#indentity operators is, is not ; a i b if a,b are pointing to the same object
a=b=23
print("a is b", a is b)
#the same memory locations
print("   id(a)  {} id(b){}".format(id(a),id(b)))
b=24
print("a is b", a is b)
#different memory locations
print("   id(a)  {} id(b){}".format(id(a),id(b)))
print("a is not b",a is not b)

#membership operators 'in','not in '

x3="Hello Python"
y3={1:'element 1',2:'element 2'}

print("Py" in x3)
print("Hellow" in x3)
print("Hellow" not in x3)

