import sys
#builtin exception zero division for example

list = [1, 2, 5,'b','a', 0]
list1=[1,2,3]
# e -get as a message , sys.exc_info  , the error type

for i in list:
    try:
        result = i/list[i]
    except Exception as e:
        print("In the except clause")
        print("the error is  {}".format(sys.exc_info()))
        print("I am going to print e now {}".format(e))
    else :
        print("There are no exceptions today")
    finally:
        print("I am finally clause and I raun anyway , doesn't matter if there were exceptions or not")

for i in range(10):
    try:

        print(i)
        if i % 2 == 0:
            raise ValueError
        elif i % 3 == 0:
            raise TimeoutError
        elif i % 5 == 0:
            raise KeyboardInterrupt
        # we have some code here
    except ValueError as ve:
        print("ve is {}".format(sys.exc_info()))# some code here
    except (KeyboardInterrupt, ValueError,TimeoutError) as yyy:
        print("yyy is {}".format(sys.exc_info()))# other errors are caught here
    finally:
        print("This will always be executed")

#else in the try except finally
for i in list1:
    try:
        rezult1=i/list1[i]
    except Exception:
        print("In except block")
    else:
        print("NO exceptions")
    finally:
        print("End of this")



#custom built exceptions
class MyNewError(Exception):
    """My new exception"""
    def __init__(self):
        Exception.__init__(self,"I am the new exception")

raise MyNewError("Hello")#the program stops here


