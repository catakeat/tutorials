a_list=[1,2,3,4,5,6]
a_iterator=iter(a_list)

for i in a_list:
    print(next(a_iterator))

#create  our own iterator

class MyIterator:
    """this will add an a to each element from a list"""

    def __init__(self,element):
        self.it = 0
        self.element = element
        self.max = len(element)

    def __iter__(self):
        return self.element

    def __next__(self):
       while self.it < self.max:
           self.it = self.it+1
           return self.element[self.it - 1]
           #print(self.it)


it=MyIterator(a_list)
it.__iter__()
for i in a_list:
    print(it.__next__())



