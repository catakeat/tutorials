"""This technique by which some data gets attached to the code is called closure in Python."""
#it's just a technique , not a real closure in PHP, C++ stylle

def one_function(a,b):
    c=a+b
    def inner_function(c):
        print(c)

    return inner_function(c)

a_function=one_function(1,5)


#functions as arguments
def sec_function(funct,a,b):
    result=funct(a,b)
    

sec_function(one_function,2,5)


