import module_to_be_imported as mi

#we could use it also as module_to_be_imported
mi.test()
print(mi.test_variable)
#show all the module content
print(dir("module_to_be_imported"))