import random as rand

class Student:
    """This is a base class for all the students"""
    student_number=rand.randint(1,10000)

    def __init__(self,name,gender):
        self.name=name
        self.gender=gender

    def displayStudent(self):
        print("Student name is {} , student gender {}".format(self.name,self.gender))


student=Student("Cata","male")

student.displayStudent()

# we have general available class attributes
print(" __doc__  {}".format(Student.__doc__))
print(" Class name {}".format(Student.__name__))
print(" Student class module is  {} ".format(Student.__module__))
print(" Student  base class {}".format(Student.__bases__))# inherits from object class
print("Student __dict__  ",Student.__dict__)
# and again let'see the student object dictionary
print(" student __dict__ ",student.__dict__)

# see the memory location

print("Student  id is {}".format(id(student)))

#let's delete the object now
del(student)

# do we still have it?
print("Student  id is {}".format(id(student)))