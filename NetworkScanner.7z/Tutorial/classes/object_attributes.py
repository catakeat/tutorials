import random as rand

class MyClass:
    """I am a docstring"""
    myvar="I am variable"

    def __init__(self):
        print("This is the constructor")

myobject=MyClass()
print(myobject.myvar)


class Vehicle:
    """This is the Vehicle class"""
    # below are class instances ; they belong to all objects
    type="Vehicle type"#SUV, Bus etc
    name="Toyota"
    color="Dark"
    price="10.000"

    def personal(self):
        #instance variable , 'personal'  for each object
        self.mileage=rand.randint(1,100)*1000
        self.year=rand.randint(1,20)+1995

        return str(self.mileage)+" "+str(self.year)

    def common(self):
        common_data=self.name+" ," +self.type+", "+self.color+", "+self.price

        return common_data


    """Not by all means necessary, you can live without having a constructor
    def __init__(self):
        pass
    """
veh1=Vehicle()
veh2=Vehicle()
print("Common data= {} + 'personal data=' {} ".format(veh1.common(),veh1.personal()))
print("veh1 __dict__ is ",veh1.__dict__)
print("Class Vehicle  __dict__ is ", Vehicle.__dict__)
print("Common data= {} + 'personal data=' {} ".format(veh2.common(),veh2.personal()))

veh3=Vehicle()
print("has attribute name {} ".format(hasattr(veh3,'name')))
print("The name is {}".format(getattr(veh3,'name')))

# we don't have 'usage attribute' but we can set it
setattr(veh3,'usage','%60')
print("Vehicle usage {} ".format(getattr(veh3,'usage')))
print("has attribute usage {}".format(hasattr(veh2,'usage')))
delattr(veh3,'usage')


