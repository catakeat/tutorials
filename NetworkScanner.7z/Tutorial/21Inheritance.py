class Person:

    def __init__(self,firstname,lastname):
        self.name = lastname+firstname



class Job(Person):

    def __init__(self,name,job):
        Person.__init__(self,"Donald ","Trump")
        self.person_job=job

    def getData(self):
        print(self.name," ",self.person_job)


class HairColor(Person,Job):
    def __init__(self,haircolor,name,job,firstname,lastname):
        self.haircolor=haircolor
        print("This person hair color is {}".format(haircolor))



job=Job("Trump","President")
job.getData()

# lets do multiple inheritance
hc=HairColor("yellow")
print("Hair Color {}".format(hc.haircolor))

