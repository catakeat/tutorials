#method overridding ----in the same class : it is a function having the same name as another one
#method overwriting -in a different class a function having the same name


class Person:

    def __init__(self,firstname,lastname):
        self.name = lastname+firstname

    #method overwritting
    def mytest(self,par1,par2):
        print("par1 and par2 {} {}".format(par1,par2))
    def mytest(self,par3):
        print("par3 {}".format(par3))

class Job(Person):

    def __init__(self,name,job):
        Person.__init__(self,"Donald ","Trump")
        self.person_job=job

    def getData(self):
        print(self.name," ",self.person_job)

    def mytest(self,par1,par2):
        print("par1 and par2 {} {}".format(par1,par2))
    def mytest(self,par3):
        print("par3 {}".format(par3))

person=Person("Barack Obama","Former Presindent")
print(person.mytest("Woora"))
#print(person.mytest("Woora","woora woora"))  # as you see we have no method overrloading in Python


job=Job("Trump","President")
job.getData()

job.mytest("1")

#some people pretend this is a overloading
def myfunction(a,b=2,c=3):
    pass
#and we may call , but I don't really consider this an overloading or overriding
myfunction(1);myfunction(1,3);myfunction(1,4,5)
