def mygen():
    n = 1
    print("This is printed first")
    yield n

    n += 1
    print("This is second")
    yield n

    n += 1
    print("This is the last")
    yield n

for i in mygen():
    print(i)
