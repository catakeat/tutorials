def myfunction():
    """I am a docstring"""
    print("This is a Python function")
    print("This is the proper way to get the doc -->'{}'".format(myfunction.__doc__))
#call the function
myfunction()

def function1(param):
    print("param is = {}".format(param))

function1("10")

#let's practise the return statement

def function_with_return(a,b,c):
    d=a+b+c# d is not visible out of the function , it is a local variable
    try:
        s=a/0;
    except:
        pass
    print(locals())
    print(globals())
    return d

my_var=function_with_return(1,2,3)
print(" my_var is {} ".format(my_var))

#let's try a recursiv function

recursiv=0

def increment(param):
    """This will work recursively till recursiv becomes 10"""
    global recursiv;
    recursiv+=1;print("recursiv is {}".format(recursiv))
    if recursiv!=10 : increment(recursiv)
    else :
        print("I am getting out of this..")
        return


increment(recursiv)

#lambda functions
result=lambda a,b,c: a*b*c
print("lambda is = {}".format(result(1,2,3)))

lambda : print("the variable recursiv is ".format(recursiv))

my_list = [1, 5, 4, 9, 8, 117, 3, 12]
print("my_list is {}".format(my_list))
new_list=list(filter(lambda x:(x%2==0),my_list))
print(new_list)

my_list1 = [1, 5, 4, 9, 8, 117, 3, 12]
new_list1=list(map(lambda x:x*2,my_list))

print("new_list1 is {}".format(new_list1))


