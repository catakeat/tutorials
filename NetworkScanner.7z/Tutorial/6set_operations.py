x=set(['java',"C++","Python"])

print(x)
#add duplicates
y=(['java',"C++","Python","java"])
print(y)# there is only one java

#make it a set
y=set(y)
print("Printing y ",y)

x.add("Scala")
print(x)
#remove all elements from set x
x.clear()
print("Printing x  ", x)

#let's maka copy now
z=y.copy()
print("Printing z ",z)
z.add("PHP")
#show the diference of one of many sets as a new set
print("Z difference y is ",z.difference(y))

#discard an element if it exist, if doesn't nothing happend
z.discard("PHP")
print(z)

#remove an element , work like discard just if the element doesn't exist raise KeyError
z.remove("java")
print(z)

print("z , y intersection is ", z.intersection(y))

#issubset()
print("is z a subset of y ? ",z.issubset(y))
#pop ;pop() removes and returns an arbitrary set element. The method raises a KeyError if the set is empty
t=y.pop()
print(t)
print(y.pop())
print(y.pop())
