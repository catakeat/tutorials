class MyClass:
    """This is a docstring"""
    a=10

    def f(self):
        print("First way {}".format(self.__doc__))
ob=MyClass()
ob.f()
print("Second way {}".format(MyClass.__doc__))


print("ob.a {}".format(ob.a))

class MyClass2:
    #Class functions that begins with double underscore
    #  (__) are called special functions as they have special meaning.

    def __init__(self,r=0,i=0):
        self.name="Jon Snow"
        self.hair=".My hair is black and curly"

    def getData(self):
        print("name and hair {} {}".format(self.name,self.hair))



ob2=MyClass2()
ob2.getData()

#delete objects attributes
del ob2.name
del ob2.hair

#ob.getData()#gives an error

#we can creat on the fly attributes
ob2.new_attribute="100points"
print(ob2.new_attribute)

#delete the entire object
del ob2
ob2.new_attribute# gives an error now