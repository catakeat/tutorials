number=10
if  number==10:
    print("The number is {}".format(number))
else :
    print("The number is not 10")

new_number=12.3
if new_number>0:#it accept paranthesis but they are redundant
    print("Greater than 0") # ..and the story stops here
elif new_number>10:
    print("new_number is greater then 10")
elif  new_number>12:
    print("new_number is greater than 12")

#nested if ..else

if new_number>0:#it accept paranthesis but they are redundant
    print("Greater than 0") # ..and the story goes ahead
    if new_number>10:
        print("new_number is greater then 10") # ..and the story goes ahead
        if new_number>12: # ..and the story goes ahead
            print("new_number is greater than 12") #stops here
