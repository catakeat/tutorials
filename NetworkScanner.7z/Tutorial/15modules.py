from module_to_be_imported import test_variable

print("test_variable is {}".format(test_variable))