import sys

#make a text.txt in the curent directory

f=open("test.txt")
f.close()
#or if we want a full path
# #f2=open("C\Users\user\My Documets\myfile.txt")

"""
r-open for reading
w-open for writing; it creates a new file if it doesn't exist; if it exist simply  overwrite it(the data)
x-opens a file fro creation ; if the file exist it no longer crates one
a-open a file for appending ;it append the content; if the file does not exist it create one
t-open a file in text mode
b-open a file in binary mode
+-open a file for updating it(read and write)

"""


f3=open("mynewfile.txt","w")
f3.write("Heloo world\n")
list_of_lines=["This is line 2\n","This is line3\n","This is line 4\n"]
f3.writelines(list_of_lines)
f3.close()

#a safer way is using try catch

try:
    f4=open("unexistentfile.txt","r");
    f4.close();
    print(sys.exc_info())

except Exception as e:
    print("in finally now");
    print(sys.exc_info())
    print(e)


    # we hv no resource to close now


#but the best way is
with open("test.txt","r") as fp:
    text=fp.read();# goes till the end of file , but we coulc specify parameters like =100
    print(text)

"""
We can change our current file cursor (position) using the seek()
 method;  tell() method returns our current position ( bytes)
"""
f5=open("test.txt","r")
txt=f5.read(10)
print("I have read \n '{}'".format(txt))
print("file pointer is {}".format(f5.tell()))
#put it again on ther first position
f5.seek(0)
print("I red again \n '{}'".format(f5.read(10)))
#rewind the file pointer
#f5.seek(0) ; we need for it in  for  because rewind does not  go autmaticaly here
print(f5.read(10))

#we can read a file line by line
for line in f5:
    print(line)  # we have line \n  from the file and the newline from the print  so a gap between lines
#otherwise reads nothing beacuse the filepointer is at the end of the file
f5.seek(0)

#see how readline works
#for line in f5:
print(f5.readline())







