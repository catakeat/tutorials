def test():
    print("I am a test from module_to_be_imported")

test_variable=" Test variable"