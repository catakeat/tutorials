#the for loop
numbers=[1,2,3,4,5,6,7,8,9]
for x in numbers:
    print(x)

#if we don't need tha x
for _ in numbers:
    print("Hello world")

print(range(10))
print(list(range(10)))

for i in range(len(numbers)):
    print(numbers[i])

num = 11
i = 0

while i <= num:
    print("i is {}".format(i))
    i += 1 #or i=i+1; we don't have the C++ i++ operator in Python

i = 0
# we have while ..else in Python

while i < num:
    print("i is smaller than num")
    i += 1
else:
    print("I am in else now")

#usage of break and continue

for i in numbers:
    print(i)
    i += 1
    if i == 1:
        continue;
        print("The story goes on")
    if i == 3 :
        break
i=0

while i < num:
    print(i)
    i += 1
    if i == 1:
        continue;
        print("The story goes on")
    if i == 2:
        break
#pass keyword does nothing
def myFunction(a,c):
    pass

with open("mynewfile.txt","a") as file:
    file.write("This was just appended")