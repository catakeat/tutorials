import numpy as np

r=np.array([[1,2,3]])

print(r.shape)
r.shape=(3,1)
print(r)
r.shape=(3,1)
r[0][0]=100
print(r[0][0])
