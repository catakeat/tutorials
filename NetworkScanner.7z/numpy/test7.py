import numpy as np

arr=np.array(range(20))
#print(arr)
arr1=arr.reshape((5,4))
#print(arr1)
print(arr1[:,-1])
print(arr1[:,-2])