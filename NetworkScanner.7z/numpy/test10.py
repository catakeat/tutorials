import numpy as np

a=np.arange(1,10)
print(a)
x=range(1,10)
print(list(x))

x1=np.arange(0.5,10.4,0.8,int)
print(x1)

t=np.array(range(42))
print(t)
print(np.ndim(t))
print(t.shape)

A = np.array([ [3.4, 8.7, 9.9],
               [1.1, -7.8, -0.7],
               [4.1, 12.3, 4.8]])
print(A)
print(np.ndim(A))
print(A.shape)