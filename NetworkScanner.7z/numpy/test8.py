import numpy as np

a=np.arange(6).reshape(3,2)
print(a)

new_a=a[:,:,np.newaxis]
print(new_a)

c=np.array([1,2,3,4])
print(c)
print(c.shape)
c.shape=(2,2)
print(c)

y=np.zeros((2,3,4))
print(y)
y.shape=(3,8)
print(y)