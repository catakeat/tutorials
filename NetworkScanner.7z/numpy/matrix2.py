import numpy as np


A=np.matrix([[1.,2],[3,4],[5,6]])

print(A)
print(A.T)

x=np.matrix("4.;5.")
print(x)
print(A*x)