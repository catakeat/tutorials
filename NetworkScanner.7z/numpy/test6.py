import numpy as np

arr=np.arange(0,20).reshape((5,4))
print(arr)
#print(np.arange(1,10))

#a=np.arange(10)
#print(a.reshape(5,-200))
print("aici")
#print(arr[3,2])
print(arr[:,0])
print("aici")
#print(arr[:,0])
print(arr[0:5:2,0:4:2])