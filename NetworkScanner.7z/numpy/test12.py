import numpy as np

x=np.array([[1,2,3],[4,5,6]],np.int32)
print(type(x))
print(x.shape)
print(x.ndim)
print(np.ndim(x))
v=x.view()
print(v)
v[0,0]=100
print(x)
