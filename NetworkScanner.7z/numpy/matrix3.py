from scipy.integrate import quad

def f(x):
    return x**4

print(quad(f,0.,3.))

print(quad(lambda x:x**4,0,3))