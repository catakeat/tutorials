import numpy as np

x=np.array(range(20)).reshape(2,10)
print(x)
y=x.copy()
x[0,0]=100
print(x)

print(y)