import numpy as np

A=np.matrix([[1.,2],[3,4],[5,6]])
print(A)

B=np.matrix("1.,2;3,4;5,6")
print(B)

x=np.matrix("10.;20.")
print(x)

print(x.T)