import numpy as np

r=np.arange(0,20).reshape((2,2,5))
print(r)
#print(r[0,0])
r[0,0]=np.array([11,22,33,44,55])
r[1,1]*=10
#r[2,2]*=10

print("R dupa ",r)

print("r[0][1]",r[0][1][0])

print("Numpy array r[0,0,1]",r[0,0,1])
