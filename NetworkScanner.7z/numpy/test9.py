import numpy as np

a=np.array([[1,2],[3,4]])
print(a.shape)

b=np.array([[5,6]])
print(b.shape)

c=np.concatenate((a,b),axis=0)
print(c)

bt=b.T

d=np.concatenate((a,bt),axis=1)
print(d)