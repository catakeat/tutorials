import numpy as np

zero=np.zeros((2,4))
print(zero)
ones=np.ones((4,6))
print(ones)
empty=np.empty((2,3))
print(empty)

print(np.arange(10,20,2))
print(np.random.random((4,4)))
