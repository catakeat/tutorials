import numpy as np

index=np.array([0,1,1,2,3])
rnd=np.random.random((10,1))
print(rnd)