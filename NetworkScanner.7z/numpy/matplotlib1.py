import matplotlib.pyplot as pyp

x=[0,2,4,6,8]
y=[0,3,3,7,0]

pyp.plot(x,y)
pyp.savefig("first.png")
pyp.show()